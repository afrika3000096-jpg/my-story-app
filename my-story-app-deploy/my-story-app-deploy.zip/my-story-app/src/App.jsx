import React, { useState, useRef, useEffect } from "react";

// 1. 챕터 설정 데이터
const CHAPTERS = [
  { id: "birth",    icon: "🌅", title: "탄생과 유년기",  prompt: "태어난 곳, 어린 시절 추억, 가족에 대해 써주세요.",      color: "#E8956D" },
  { id: "school",   icon: "📚", title: "학창 시절",      prompt: "학교생활, 친구들, 선생님, 꿈에 대해 써주세요.",         color: "#5B8DB8" },
  { id: "youth",    icon: "🌱", title: "청년 시절",      prompt: "처음 사회에 나갔을 때, 도전과 성장에 대해 써주세요.",    color: "#6BAA75" },
  { id: "love",     icon: "❤️", title: "사랑과 관계",    prompt: "소중한 인연, 사랑, 우정에 대해 써주세요.",             color: "#C4647A" },
  { id: "career",   icon: "💼", title: "일과 커리어",    prompt: "직업, 일하며 겪은 경험, 성취에 대해 써주세요.",         color: "#8B7EC8" },
  { id: "hardship", icon: "🌧️", title: "역경과 극복",    prompt: "힘들었던 순간과 그것을 이겨낸 이야기를 써주세요.",      color: "#7AAABB" },
  { id: "joy",      icon: "✨", title: "기쁨과 자랑",    prompt: "가장 행복했던 순간, 자랑스러운 기억을 써주세요.",       color: "#D4A843" },
  { id: "legacy",   icon: "✉️", title: "남기고 싶은 말", prompt: "가족이나 후세에게 전하고 싶은 메시지를 적어보세요.",     color: "#7BAB8B" },
];

export default function AutobiographyApp() {
  const [data, setData] = useState(() => {
    try {
      const saved = localStorage.getItem("autobio_v7");
      return saved ? JSON.parse(saved) : { author: "", entries: {} };
    } catch(e) { return { author: "", entries: {} }; }
  });

  const [activeTab, setActiveTab] = useState("birth");
  const [aiLoading, setAiLoading] = useState(false);
  const [aiResult, setAiResult] = useState("");
  const [videoPreview, setVideoPreview] = useState(null);
  const [isSaved, setIsSaved] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [showPreview, setShowPreview] = useState(false);
  const videoUrlRef = useRef(null);

  useEffect(() => {
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = "https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=Noto+Serif+KR:wght@300;400;600&display=swap";
    document.head.appendChild(link);
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      localStorage.setItem("autobio_v7", JSON.stringify(data));
      setIsSaved(true);
    }, 800);
    return () => clearTimeout(timer);
  }, [data]);

  const activeChapter = CHAPTERS.find(c => c.id === activeTab) || CHAPTERS[0];
  const currentContent = data.entries[activeTab]?.text || "";
  const completedCount = CHAPTERS.filter(c =>
    data.entries[c.id]?.text && data.entries[c.id].text.trim().length > 0
  ).length;
  const pct = Math.round((completedCount / CHAPTERS.length) * 100);

  const handleTextChange = (e) => {
    const text = e.target.value;
    setIsSaved(false);
    setData(prev => ({
      ...prev,
      entries: { ...prev.entries, [activeTab]: { ...prev.entries[activeTab], text } }
    }));
  };

  const askAI = async () => {
    if (aiLoading) return;
    setAiLoading(true); setAiResult("");
    setTimeout(() => {
      setAiResult(`"${activeChapter.title}"에 대해 적어주신 글을 읽어보았습니다.\n당시의 분위기를 정말 생생하게 묘사하셨네요.\n그때 느꼈던 감정을 조금 더 깊게 들여다보면, 독자들에게 더 큰 울림을 줄 수 있을 것 같습니다.\n계속해서 당신의 이야기를 들려주세요.`);
      setAiLoading(false);
    }, 1500);
  };

  const handleVideoUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (videoUrlRef.current) URL.revokeObjectURL(videoUrlRef.current);
    const url = URL.createObjectURL(file);
    videoUrlRef.current = url;
    setVideoPreview(url);
  };

  const PreviewModal = () => {
    const written = CHAPTERS.filter(c => data.entries[c.id]?.text?.trim());
    return (
      <div style={S.previewOverlay} onClick={() => setShowPreview(false)}>
        <div style={S.previewModal} onClick={e => e.stopPropagation()}>
          <div style={S.previewHeader}>
            <div>
              <div style={S.previewTitle}>📖 나의 인생 자서전</div>
              <div style={S.previewSub}>{written.length}개의 기록이 담겨 있습니다.</div>
            </div>
            <button style={S.previewClose} onClick={() => setShowPreview(false)}>✕</button>
          </div>
          <div style={S.previewBody}>
            {written.length === 0 ? (
              <div style={S.previewEmpty}>아직 작성된 이야기가 없네요.<br/>첫 페이지를 시작해볼까요? ✍️</div>
            ) : (
              written.map(ch => (
                <div key={ch.id} style={S.previewChapter}>
                  <div style={S.previewChapterHeader}>
                    <div style={{ ...S.previewChapterBar, background: ch.color }} />
                    <div style={{ ...S.previewChapterLabel, color: ch.color }}>{ch.icon} {ch.title}</div>
                  </div>
                  <p style={S.previewChapterText}>{data.entries[ch.id].text}</p>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div style={S.root}>
      {showPreview && <PreviewModal />}

      <aside style={{ ...S.sidebar, marginLeft: sidebarOpen ? 0 : -240 }}>
        <div style={S.brand}>
          <div style={S.brandIcon}>✍</div>
          <div>
            <div style={S.brandTitle}>인생의 기록</div>
            <div style={S.brandSub}>나의 이야기 쓰기</div>
          </div>
        </div>

        <div style={S.ringWrap}>
          <svg width="72" height="72">
            <circle cx="36" cy="36" r="30" fill="none" stroke="#E8E0D4" strokeWidth="5"/>
            <circle cx="36" cy="36" r="30" fill="none" stroke="#C4A882" strokeWidth="5"
              strokeDasharray={188.4} strokeDashoffset={188.4 * (1 - pct / 100)}
              strokeLinecap="round" transform="rotate(-90 36 36)"
              style={{ transition: "stroke-dashoffset 0.6s ease" }}
            />
            <text x="36" y="41" textAnchor="middle" fill="#A8896A" fontSize="14" fontWeight="bold">{pct}%</text>
          </svg>
          <div style={S.ringLabel}>{completedCount} / {CHAPTERS.length} 챕터 완료</div>
        </div>

        <nav style={S.chapterNav}>
          {CHAPTERS.map(ch => {
            const done = !!data.entries[ch.id]?.text?.trim();
            const active = activeTab === ch.id;
            return (
              <button key={ch.id}
                style={{
                  ...S.navItem,
                  background: active ? ch.color + "18" : "transparent",
                  borderLeft: active ? `3px solid ${ch.color}` : "3px solid transparent",
                  color: active ? ch.color : (done ? "#5A5550" : "#9A9088"),
                }}
                onClick={() => { setActiveTab(ch.id); setAiResult(""); }}>
                <span style={S.navIcon}>{done ? "✓" : ch.icon}</span>
                <span style={{ ...S.navTitle, fontWeight: active ? 700 : 400 }}>{ch.title}</span>
              </button>
            );
          })}
        </nav>

        <div style={S.sidebarFooter}>
          <button style={S.previewBtn} onClick={() => setShowPreview(true)}>👁 전체 미리보기</button>
          <div style={S.saveStatus}>
            <span style={{ ...S.dot, background: isSaved ? "#6BAA75" : "#D4A843" }} />
            {isSaved ? "저장 완료" : "변경사항 저장 중..."}
          </div>
        </div>
      </aside>

      <main style={S.main}>
        <header style={S.topBar}>
          <button style={S.menuBtn} onClick={() => setSidebarOpen(!sidebarOpen)}>
            {sidebarOpen ? "✕" : "☰"}
          </button>
          <div style={S.breadcrumb}>
            <span style={S.breadcrumbSub}>자서전 집필</span>
            <span style={S.breadcrumbSep}>›</span>
            <span style={{ ...S.breadcrumbActive, color: activeChapter.color }}>{activeChapter.title}</span>
          </div>
        </header>

        <div style={S.scrollArea}>
          <div style={{ ...S.chapterHero, borderBottom: `1px solid ${activeChapter.color}33` }}>
            <div style={{ ...S.chapterAccent, background: activeChapter.color }} />
            <div style={S.chapterMeta}>
              <span style={{ ...S.chapterLabel, color: activeChapter.color }}>Chapter {CHAPTERS.findIndex(c => c.id === activeTab) + 1}</span>
              <h1 style={S.chapterHeading}>{activeChapter.title}</h1>
              <p style={S.chapterPrompt}>{activeChapter.prompt}</p>
            </div>
            <div style={S.chapterEmoji}>{activeChapter.icon}</div>
          </div>

          <div style={S.editorWrap}>
            <textarea
              style={{ ...S.textarea, caretColor: activeChapter.color }}
              placeholder={`${activeChapter.title}에 대한 당신의 소중한 기억을 들려주세요...`}
              value={currentContent}
              onChange={handleTextChange}
            />
            <div style={S.charCount}>{currentContent.length.toLocaleString()} 자 작성 중</div>
          </div>

          <div style={S.actions}>
            <button style={{ ...S.aiBtn, background: activeChapter.color }} onClick={askAI} disabled={aiLoading}>
              {aiLoading ? "⟳ AI 코치가 읽는 중..." : "✦ AI 글쓰기 코칭"}
            </button>
            <label style={S.videoBtn}>
              🎬 영상 첨부
              <input type="file" accept="video/*" onChange={handleVideoUpload} style={{ display: "none" }} />
            </label>
          </div>

          {aiResult && (
            <div style={{ ...S.aiBox, borderColor: activeChapter.color + "44" }}>
              <div style={S.aiBoxHeader}>
                <span style={{ ...S.aiBoxTag, background: activeChapter.color }}>AI COACH</span>
                <button style={S.aiBoxClose} onClick={() => setAiResult("")}>✕</button>
              </div>
              <p style={S.aiBoxText}>{aiResult}</p>
            </div>
          )}

          {videoPreview && (
            <div style={S.videoWrap}>
              <div style={{ ...S.videoLabelBar, color: activeChapter.color }}>🎬 첨부된 영상 메모</div>
              <video src={videoPreview} controls style={S.video} />
            </div>
          )}

          <div style={S.chapterNav2}>
            {CHAPTERS.findIndex(c => c.id === activeTab) > 0 && (
              <button style={S.navArrow} onClick={() => {
                const idx = CHAPTERS.findIndex(c => c.id === activeTab);
                setActiveTab(CHAPTERS[idx - 1].id); setAiResult("");
              }}>← 이전</button>
            )}
            <div style={{ flex: 1 }} />
            {CHAPTERS.findIndex(c => c.id === activeTab) < CHAPTERS.length - 1 && (
              <button style={{ ...S.navArrow, background: activeChapter.color, color: "#fff", border: "none" }}
                onClick={() => {
                  const idx = CHAPTERS.findIndex(c => c.id === activeTab);
                  setActiveTab(CHAPTERS[idx + 1].id); setAiResult("");
                }}>다음 →</button>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

const S = {
  root: { display: "flex", height: "100vh", background: "#F5F0E8", fontFamily: "'Noto Serif KR', serif", overflow: "hidden" },
  sidebar: {
    width: 240, flexShrink: 0, background: "#FDFAF5", borderRight: "1px solid #E8E0D4",
    display: "flex", flexDirection: "column", transition: "margin-left 0.3s ease", zIndex: 100
  },
  brand: { padding: "24px 20px", borderBottom: "1px solid #EDE6DC", display: "flex", alignItems: "center", gap: 12 },
  brandIcon: { width: 36, height: 36, background: "#C4A882", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", borderRadius: 8, fontSize: 18 },
  brandTitle: { fontSize: 15, fontWeight: 700, color: "#3A3028" },
  brandSub: { fontSize: 11, color: "#B0A898" },
  ringWrap: { display: "flex", flexDirection: "column", alignItems: "center", padding: "20px 0", borderBottom: "1px solid #EDE6DC" },
  ringLabel: { fontSize: 12, color: "#B0A898", marginTop: 8 },
  chapterNav: { flex: 1, padding: "10px 0", overflowY: "auto" },
  navItem: { width: "100%", padding: "12px 20px", border: "none", display: "flex", alignItems: "center", gap: 10, cursor: "pointer", textAlign: "left", background: "transparent", fontFamily: "inherit" },
  navIcon: { width: 20, fontSize: 14 },
  navTitle: { fontSize: 13 },
  sidebarFooter: { padding: "16px", borderTop: "1px solid #EDE6DC" },
  previewBtn: { width: "100%", padding: "10px", borderRadius: 10, border: "1px solid #D8CFBF", background: "#fff", cursor: "pointer", fontWeight: 700, fontSize: 13, color: "#6A5E50" },
  saveStatus: { display: "flex", alignItems: "center", justifyContent: "center", gap: 6, fontSize: 11, color: "#B0A898", marginTop: 10 },
  dot: { width: 6, height: 6, borderRadius: "50%" },
  main: { flex: 1, display: "flex", flexDirection: "column", background: "#FDFBF8" },
  topBar: { display: "flex", alignItems: "center", padding: "12px 24px", borderBottom: "1px solid #EDE6DC", background: "rgba(253, 251, 248, 0.8)", backdropFilter: "blur(4px)" },
  menuBtn: { width: 32, height: 32, border: "1px solid #D8CFBF", background: "#fff", cursor: "pointer", borderRadius: 6 },
  breadcrumb: { marginLeft: 16, display: "flex", alignItems: "center", gap: 8, fontSize: 13 },
  breadcrumbSub: { color: "#B0A898" },
  breadcrumbSep: { color: "#D8CFBF" },
  breadcrumbActive: { fontWeight: 700 },
  scrollArea: { flex: 1, overflowY: "auto", paddingBottom: 60 },
  chapterHero: { padding: "40px 40px 30px", display: "flex", alignItems: "flex-start", position: "relative" },
  chapterAccent: { width: 4, height: 60, marginRight: 20, borderRadius: 2 },
  chapterMeta: { flex: 1 },
  chapterLabel: { fontSize: 11, fontWeight: 700, letterSpacing: 2 },
  chapterHeading: { fontSize: 28, margin: "8px 0", color: "#1A1610" },
  chapterPrompt: { fontSize: 14, color: "#9A9088", fontStyle: "italic" },
  chapterEmoji: { fontSize: 48, opacity: 0.1 },
  editorWrap: { padding: "0 40px" },
  textarea: { width: "100%", minHeight: 300, border: "none", borderBottom: "1px solid #EDE6DC", background: "transparent", fontSize: 16, lineHeight: 1.8, outline: "none", resize: "none", padding: "20px 0", boxSizing: "border-box" },
  charCount: { textAlign: "right", fontSize: 11, color: "#C8C0B4", marginTop: 8 },
  actions: { padding: "24px 40px", display: "flex", gap: 12 },
  aiBtn: { flex: 2, padding: "14px", borderRadius: 12, border: "none", color: "#fff", fontWeight: 700, cursor: "pointer", boxShadow: "0 4px 12px rgba(0,0,0,0.1)" },
  videoBtn: { flex: 1, padding: "14px", borderRadius: 12, border: "1px solid #D8CFBF", background: "#fff", textAlign: "center", cursor: "pointer", fontSize: 13, fontWeight: 600 },
  aiBox: { margin: "20px 40px", borderRadius: 12, border: "1px solid", background: "#fff", overflow: "hidden" },
  aiBoxHeader: { padding: "10px 16px", borderBottom: "1px solid #F0EBE3", display: "flex", justifyContent: "space-between", alignItems: "center" },
  aiBoxTag: { fontSize: 10, color: "#fff", padding: "2px 8px", borderRadius: 4, fontWeight: 800 },
  aiBoxClose: { background: "none", border: "none", cursor: "pointer", color: "#B0A898" },
  aiBoxText: { padding: "16px", fontSize: 14, lineHeight: 1.7, fontStyle: "italic", color: "#4A4038" },
  videoWrap: { margin: "20px 40px", borderRadius: 12, overflow: "hidden", background: "#000" },
  videoLabelBar: { padding: "8px 16px", background: "#F5F0E8", fontSize: 12, fontWeight: 700 },
  video: { width: "100%", maxHeight: 300 },
  chapterNav2: { padding: "40px", display: "flex", gap: 12 },
  navArrow: { padding: "10px 20px", borderRadius: 8, border: "1px solid #D8CFBF", background: "#fff", cursor: "pointer", fontSize: 13, fontWeight: 700 },
  previewOverlay: { position: "fixed", inset: 0, background: "rgba(0,0,0,0.5)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000, padding: 20 },
  previewModal: { background: "#FDFAF5", width: "100%", maxWidth: 700, maxHeight: "90vh", borderRadius: 20, display: "flex", flexDirection: "column", overflow: "hidden" },
  previewHeader: { padding: "20px 24px", borderBottom: "1px solid #EDE6DC", display: "flex", justifyContent: "space-between", alignItems: "center", background: "#fff" },
  previewTitle: { fontSize: 20, fontWeight: 700 },
  previewSub: { fontSize: 13, color: "#B0A898", marginTop: 4 },
  previewClose: { background: "none", border: "none", fontSize: 18, cursor: "pointer", color: "#9A9088" },
  previewBody: { flex: 1, overflowY: "auto", padding: "24px" },
  previewEmpty: { textAlign: "center", color: "#B0A898", padding: "60px 20px", lineHeight: 2 },
  previewChapter: { marginBottom: 30, background: "#fff", padding: "20px", borderRadius: 12, boxShadow: "0 2px 8px rgba(0,0,0,0.05)" },
  previewChapterHeader: { display: "flex", alignItems: "center", gap: 10, marginBottom: 12 },
  previewChapterBar: { width: 4, height: 20, borderRadius: 2 },
  previewChapterLabel: { fontSize: 14, fontWeight: 700 },
  previewChapterText: { fontSize: 15, lineHeight: 1.8, color: "#333", whiteSpace: "pre-wrap", margin: 0 }
};
